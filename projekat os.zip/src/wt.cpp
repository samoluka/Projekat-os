#include "wt.h"
#include <IOSTREAM.H>
#include "thread.h"
#include "PCB.h"

extern volatile int critical;

void WaitingThread::run() {
    while (1) {
    };
}